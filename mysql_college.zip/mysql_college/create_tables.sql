DROP DATABASE IF EXISTS college;
CREATE DATABASE college;
USE college;

-- Class table
-- sid,cno,cname,credits,grade
CREATE TABLE Class(
    sid char(12),
    cno char(6),
    cname varchar(200),
    credits integer,
    grade char(2)
);

-- Student table
-- sid,fname,lname,dob,status
CREATE TABLE Student(
    sid char(12),
    fname varchar(200),
    lname varchar(200),
    dob date,
    status char(3)
);

-- Instructor table
-- tid,name,dept
CREATE TABLE Instructor(
    tid char(12),
    name varchar(200),
    dept varchar(200)
);

-- Instructor table
-- tid,name,dept
CREATE TABLE Teaches(
    tid char(12),
    cno char(6)
);